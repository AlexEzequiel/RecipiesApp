package com.platzi.misrecetas.model

import java.io.Serializable

class Recetas: Serializable {
    var nombreRecetas = ""
    var fotoRecetas = ""
    var categoria = ""
    var ingredientesReceta = ""
    var preparacionReceta = ""
    var posicion = 0
}