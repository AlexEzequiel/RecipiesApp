package com.platzi.misrecetas.view.fragments

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.platzi.misrecetas.model.Recetas
import com.platzi.misrecetas.viewmodel.RecetasViewModel

class RecyclerRecetasAdapter(var recetasViewModel: RecetasViewModel, var resource: Int) : RecyclerView.Adapter<RecyclerRecetasAdapter.CardCouponHolder>() {

    private var recetas :List<Recetas>? = null
    fun setCouponList(coupons: List<Coupon>?){
        this.coupons = coupons

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): CardCouponHolder {
        var layoutInflater: LayoutInflater = LayoutInflater.from(p0.context)
        var binding: ViewDataBinding = DataBindingUtil.inflate(layoutInflater, p1, p0,false)
        return CardCouponHolder(binding)
    }

    override fun getItemCount(): Int {
        return recetas?.size ?: 0
    }

    override fun onBindViewHolder(p0: CardCouponHolder, p1: Int) {
        p0.setDataCard(recetasViewModel, p1)
    }

    override fun getItemViewType(position: Int): Int {
        return getLayoutIdForPosition(position)
    }
    fun getLayoutIdForPosition(position: Int): Int{
        return resource

    }

    class CardCouponHolder(binding: ViewDataBinding) : RecyclerView.ViewHolder(binding.root){
        private var binding: ViewDataBinding? = null

        init {
            this.binding = binding
        }

        fun setDataCard(couponViewModel: CouponViewModel, position: Int){
            binding?.setVariable(BR.model,couponViewModel)
            binding?.setVariable(BR.position,position)
            binding?.executePendingBindings()

        }


    }

}