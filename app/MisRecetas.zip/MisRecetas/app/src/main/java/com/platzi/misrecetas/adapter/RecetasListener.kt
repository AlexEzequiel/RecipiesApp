package com.platzi.misrecetas.adapter

import com.platzi.misrecetas.model.Recetas

interface RecetasListener {
    fun onRecetaClicked(speakers: Recetas, position:Int) }