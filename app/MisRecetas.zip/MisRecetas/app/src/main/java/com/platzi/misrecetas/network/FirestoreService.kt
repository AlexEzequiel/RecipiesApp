package com.platzi.misrecetas.network

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.platzi.misrecetas.model.Recetas

const val RECETAS_COLLECTION_NAME = "recetas"


class FirestoreService {
    val firebaseFirestore = FirebaseFirestore.getInstance()
    val settings = FirebaseFirestoreSettings.Builder().setPersistenceEnabled(true).build()

    init {
        firebaseFirestore.firestoreSettings = settings
    }

    fun getRecetas(callback: Callback<List<Recetas>>) {
        firebaseFirestore.collection(RECETAS_COLLECTION_NAME)
            .orderBy("category")
            .get()
            .addOnSuccessListener { result ->
                for (doc in result){
                    val list = result.toObjects(Recetas::class.java)
                    callback.onSuccess(list)
                    break
                }
            }
    }
}