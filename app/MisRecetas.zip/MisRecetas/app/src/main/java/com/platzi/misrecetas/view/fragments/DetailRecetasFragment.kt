package com.platzi.misrecetas.view.fragments

class DetailRecetasFragment {
}